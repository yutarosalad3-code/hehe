/* Runs before styles paint, so a saved dark preference never flashes light. */
(() => {
  'use strict';
  const root = document.documentElement;
  const storageKey = 'forma-theme';
  const modes = ['light', 'dark', 'system'];
  const system = window.matchMedia('(prefers-color-scheme: dark)');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let preference = 'system';
  let transition = null;
  let cleanupTimer;
  try {
    const saved = localStorage.getItem(storageKey);
    if (modes.includes(saved)) preference = saved;
  } catch (_) { /* Theme selection still works when storage is unavailable. */ }

  // Optional initial-theme links are consumed, not saved over a user's preference.
  const url = new URL(location.href);
  const initialTheme = url.searchParams.get('theme');
  if (modes.includes(initialTheme)) {
    preference = initialTheme;
    url.searchParams.delete('theme');
    try { history.replaceState(history.state, '', url); } catch (_) {}
  }

  const icons = {
    light: '<circle cx="12" cy="12" r="3.5"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    dark: '<path d="M20.4 14.3A8.6 8.6 0 0 1 9.7 3.6a8.6 8.6 0 1 0 10.7 10.7Z"/>',
    system: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>'
  };

  function resolvedTheme() {
    return preference === 'system' ? (system.matches ? 'dark' : 'light') : preference;
  }

  function updateControls() {
    const select = document.getElementById('theme-select');
    if (select) select.value = preference;
    const icon = document.getElementById('theme-icon');
    if (icon) icon.innerHTML = icons[preference];
    const label = document.getElementById('theme-control');
    if (label) label.title = `Appearance: ${preference === 'system' ? `System (${resolvedTheme()})` : preference}`;
  }

  function applyTheme() {
    const resolved = resolvedTheme();
    root.dataset.theme = resolved;
    root.dataset.themePreference = preference;
    root.style.colorScheme = resolved;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'dark' ? '#151b18' : '#f9faf7');
    updateControls();
  }

  function announceTheme() {
    const status = document.getElementById('theme-status');
    if (status) status.textContent = preference === 'system'
      ? `Following your system appearance. ${resolvedTheme()} mode is active.`
      : `${preference === 'dark' ? 'Dark' : 'Light'} mode is active.`;
  }

  function changeTheme(animate = true) {
    transition?.skipTransition();
    transition = null;
    clearTimeout(cleanupTimer);
    root.classList.remove('theme-transition');
    if (!animate || reducedMotion.matches || root.dataset.theme === resolvedTheme()) {
      applyTheme();
      announceTheme();
      return;
    }
    if (typeof document.startViewTransition === 'function') {
      // Reading the latest preference inside the callback also handles rapid changes.
      transition = document.startViewTransition(applyTheme);
      const active = transition;
      active.ready.catch(() => {});
      active.finished.catch(() => {}).finally(() => {
        if (transition === active) transition = null;
      });
    } else {
      // Progressive enhancement: the same gentle color transition in older browsers.
      root.classList.add('theme-transition');
      applyTheme();
      cleanupTimer = setTimeout(() => root.classList.remove('theme-transition'), 280);
    }
    announceTheme();
  }

  function setPreference(mode) {
    if (!modes.includes(mode)) return;
    preference = mode;
    try { localStorage.setItem(storageKey, mode); } catch (_) {}
    changeTheme();
  }

  system.addEventListener('change', () => { if (preference === 'system') changeTheme(); });
  reducedMotion.addEventListener('change', () => {
    if (reducedMotion.matches) {
      transition?.skipTransition();
      root.classList.remove('theme-transition');
      applyTheme();
    }
  });
  window.addEventListener('storage', event => {
    if (event.key !== storageKey && event.key !== null) return;
    preference = modes.includes(event.newValue) ? event.newValue : 'system';
    changeTheme();
  });

  applyTheme();
  document.addEventListener('DOMContentLoaded', () => {
    updateControls();
    document.getElementById('theme-select')?.addEventListener('change', event => setPreference(event.target.value));
  });
})();
