'use strict';
const view = document.getElementById('view');
const announcer = document.getElementById('announcer');
const state = { view: 'signin', step: 1, maxStep: 1, pending: false, scenario: 'normal', signedIn: false, created: false, editing: false,
  auth: { email: '', password: '', remember: false },
  signup: { firstName: '', middleName: '', lastName: '', email: '', phone: '', phoneCountry: 'PH', phoneNational: '', username: '', hobby: '', birthday: '', password: '', confirmPassword: '', agreement: false },
  setup: { step: 0, complete: false, displayName: '', updates: 'important' }, resetEmail: '' };
try { state.auth.email = localStorage.getItem('forma-remembered-email') || ''; state.auth.remember = !!state.auth.email; } catch (_) { /* Storage may be unavailable in private browsing. */ }
const escapeHTML = (value) => String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const eye = '<svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M2 10s3-5 8-5 8 5 8 5-3 5-8 5-8-5-8-5Z" stroke="currentColor" stroke-width="1.2"/><circle cx="10" cy="10" r="2" stroke="currentColor" stroke-width="1.2"/></svg>';
const arrow = '<span class="button-arrow" aria-hidden="true">→</span>';
const groups = { 1: ['firstName', 'lastName', 'middleName', 'email', 'phone'], 2: ['username', 'hobby', 'birthday', 'password', 'confirmPassword'] };
const definitions = {
  firstName: ['First name', 'Enter your first name', 'text', 'given-name'],
  middleName: ['Middle name', 'Enter your middle name', 'text', 'additional-name'],
  lastName: ['Last name', 'Enter your last name', 'text', 'family-name'],
  email: ['Email address', 'name@example.com', 'email', 'email'],
  phone: ['Phone number', '+63 9XX XXX XXXX', 'tel', 'tel'],
  username: ['Username', 'Choose a username', 'text', 'username'],
  hobby: ['What’s your hobby?', 'e.g. Gardening or 3D printing', 'text', 'off'],
  birthday: ['Birthday', '', 'date', 'bday'],
  password: ['Password', 'Create a password', 'password', 'new-password'],
  confirmPassword: ['Confirm password', 'Re-enter your password', 'password', 'new-password']
};
const passwordRules = [
  ['length', 'At least 8 characters', v => v.length >= 8],
  ['upper', 'One uppercase letter', v => /[A-Z]/.test(v)],
  ['lower', 'One lowercase letter', v => /[a-z]/.test(v)],
  ['number', 'One number', v => /[0-9]/.test(v)]
];
function passwordStrength(value) {
  const met = passwordRules.filter(([, , test]) => test(value)).length;
  if (!value) return { met: 0, label: 'Not set', tone: 'empty' };
  if (met <= 1) return { met, label: 'Weak', tone: 'weak' };
  if (met === 2) return { met, label: 'Fair', tone: 'fair' };
  if (met === 3) return { met, label: 'Good', tone: 'good' };
  return { met, label: 'Strong', tone: 'strong' };
}
function birthdayDetails(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) return null;
  const today = new Date();
  const currentYear = today.getFullYear(), currentMonth = today.getMonth() + 1, currentDay = today.getDate();
  const isTodayOrFuture = year > currentYear || (year === currentYear && (month > currentMonth || (month === currentMonth && day >= currentDay)));
  let age = currentYear - year;
  if (month > currentMonth || (month === currentMonth && day > currentDay)) age--;
  return { age, isTodayOrFuture };
}
function birthdayHelper(value) {
  const details = birthdayDetails(value);
  return details && !details.isTodayOrFuture ? `You are ${details.age} years old.` : 'Choose a past date to see your age.';
}
function latestBirthday() {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
}
const isNameField = name => ['firstName', 'middleName', 'lastName'].includes(name);
const requiredMark = '<span class="required-marker" aria-hidden="true"> *</span>';
const nameCharacters = /^[\p{L}\p{M} '’\-]*$/u;
const namePattern = /^\p{L}[\p{L}\p{M}]*(?:[ '’\-]\p{L}[\p{L}\p{M}]*)*$/u;
const nameInputMessage = 'Numbers and symbols weren’t added. Use letters.';
function capitalizeName(value) {
  // Preserve intentional capitals such as McDonald; capitalize each name part only.
  return value.replace(/(^|[ '’\-])(\p{L})/gu, (_, separator, letter) => separator + letter.toLocaleUpperCase());
}
function normalizeName(value) { return capitalizeName(value.normalize('NFC').trim().replace(/ +/g, ' ')); }
function capitalizeNameInput(input) {
  if (!isNameField(input.name)) return;
  const value = input.value;
  const next = capitalizeName(value);
  if (value === next) return;
  const start = input.selectionStart;
  const end = input.selectionEnd;
  input.value = next;
  if (start !== null && end !== null) input.setSelectionRange(capitalizeName(value.slice(0, start)).length, capitalizeName(value.slice(0, end)).length);
}
function validEmail(value) {
  if (value.length > 254 || /\s/.test(value)) return false;
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  const [local, domain] = parts;
  if (!local || local.length > 64 || !/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~\-]+$/.test(local) || local.startsWith('.') || local.endsWith('.') || local.includes('..')) return false;
  const labels = domain.split('.');
  return labels.length >= 2 && labels.every(label => label.length <= 63 && /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(label)) && /^(?:[a-zA-Z]{2,}|xn--[a-zA-Z0-9-]+)$/.test(labels.at(-1));
}
function validPhone(value) {
  // International format; allow ordinary grouping, not arbitrary punctuation.
  const digits = value.replace(/\D/g, '');
  return value.length <= 32 && digits.length >= 7 && digits.length <= 15 && /^\+[1-9]\d*(?:[ -]?\d+| ?\(\d+\))*$/.test(value);
}
const phoneCountries = [
  ['PH', 'Philippines', '+63'], ['US', 'United States', '+1'], ['CA', 'Canada', '+1'],
  ['GB', 'United Kingdom', '+44'], ['AU', 'Australia', '+61'], ['NZ', 'New Zealand', '+64'],
  ['SG', 'Singapore', '+65'], ['MY', 'Malaysia', '+60'], ['ID', 'Indonesia', '+62'],
  ['TH', 'Thailand', '+66'], ['VN', 'Vietnam', '+84'], ['IN', 'India', '+91'],
  ['CN', 'China', '+86'], ['JP', 'Japan', '+81'], ['KR', 'South Korea', '+82'],
  ['HK', 'Hong Kong', '+852'], ['TW', 'Taiwan', '+886'], ['AE', 'United Arab Emirates', '+971'],
  ['SA', 'Saudi Arabia', '+966'], ['DE', 'Germany', '+49'], ['FR', 'France', '+33'],
  ['ES', 'Spain', '+34'], ['IT', 'Italy', '+39'], ['ZA', 'South Africa', '+27']
];
function selectedPhoneCountry() {
  return phoneCountries.find(country => country[0] === state.signup.phoneCountry) || phoneCountries[0];
}
function updatePhoneCountryUI() {
  const [code, country, dial] = selectedPhoneCountry();
  const select = document.getElementById('phone-country');
  if (!select) return;
  select.value = code;
  document.getElementById('phone-country-flag').src = `https://flagcdn.com/${code.toLowerCase()}.svg`;
  document.getElementById('phone-country-code').textContent = dial;
  document.getElementById('phone-country-name').textContent = country;
  document.getElementById('phone').placeholder = code === 'PH' ? '917 123 4567' : 'Enter phone number';
  document.getElementById('phone-helper').textContent = `${country} (${dial}). Enter the number without the country code.`;
}
function savePhone(raw) {
  let national = raw;
  // Full international numbers pasted/autofilled into the number box are split once.
  if (raw.trim().startsWith('+')) {
    const international = raw.trim();
    const current = selectedPhoneCountry();
    const country = international.startsWith(current[2]) ? current : [...phoneCountries].sort((a, b) => b[2].length - a[2].length).find(item => international.startsWith(item[2]));
    if (country) {
      state.signup.phoneCountry = country[0];
      national = international.slice(country[2].length).trimStart();
      const input = document.getElementById('phone');
      if (input) input.value = national;
      updatePhoneCountryUI();
    }
  }
  state.signup.phoneNational = national;
  const dial = selectedPhoneCountry()[2];
  state.signup.phone = national.trim() ? `${dial} ${national.trim()}` : '';
}
function phoneField() {
  const [code, country, dial] = selectedPhoneCountry();
  return `<div class="field"><div class="phone-fields"><div><div class="field-label"><label for="phone-country">Country code${requiredMark}</label></div><div class="phone-country-control"><span class="phone-country-display" aria-hidden="true"><img id="phone-country-flag" src="https://flagcdn.com/${code.toLowerCase()}.svg" alt="" width="22" height="16"><span id="phone-country-name">${country}</span><span id="phone-country-code">${dial}</span><span class="phone-country-chevron">⌄</span></span><select id="phone-country" name="phoneCountry" required autocomplete="tel-country-code" aria-describedby="phone-helper">${phoneCountries.map(([iso, name, prefix]) => `<option value="${iso}" ${code === iso ? 'selected' : ''}>${name} (${prefix}) ${String.fromCodePoint(...[...iso].map(char => char.charCodeAt(0) + 127397))}</option>`).join('')}</select></div></div><div class="phone-national-field"><div class="field-label"><label for="phone">Phone number${requiredMark}</label></div><input id="phone" name="phone" type="tel" inputmode="tel" autocomplete="tel-national" placeholder="${code === 'PH' ? '917 123 4567' : 'Enter phone number'}" value="${escapeHTML(state.signup.phoneNational)}" maxlength="32" required aria-invalid="false" aria-describedby="phone-helper phone-error"></div></div><div class="field-feedback"><p class="helper-text" id="phone-helper">${country} (${dial}). Enter the number without the country code.</p><p class="error-text" id="phone-error" aria-live="polite"></p></div></div>`;
}
function field(name, context = 'signup') {
  if (name === 'phone' && context === 'signup') return phoneField();
  const [label, originalPlaceholder, type, autocomplete] = definitions[name];
  const isAuthPassword = context === 'auth' && name === 'password';
  const placeholder = isAuthPassword ? 'Enter your password' : originalPlaceholder;
  const value = context === 'reset' ? state.resetEmail : state[context][name];
  const hasRequirements = context === 'signup' && name === 'password';
  const helper = isNameField(name) ? 'Letters, spaces, apostrophes, or hyphens.' : name === 'phone' ? 'Start with + and your country code (e.g. +63).' : name === 'username' ? '3–24 characters. Letters, numbers, and underscores.' : name === 'hobby' ? '2–60 characters. Letters, numbers, spaces, apostrophes, hyphens, commas, and & are allowed.' : name === 'birthday' ? birthdayHelper(value || '') : '';
  const maxLength = isNameField(name) || name === 'hobby' ? 60 : name === 'username' ? 24 : type === 'password' ? 128 : name === 'phone' ? 32 : 254;
  const strength = passwordStrength(value || '');
  return `<div class="field${isNameField(name) ? ' name-field' : ''}"><div class="field-label"><label for="${name}">${label}${name === 'middleName' ? ' <span class="optional-label">(optional)</span>' : requiredMark}</label></div><div class="${type === 'password' ? 'input-wrap' : ''}"><input id="${name}" name="${name}" type="${type}" placeholder="${placeholder}" value="${escapeHTML(value || '')}" autocomplete="${isAuthPassword ? 'current-password' : autocomplete}" ${type === 'email' || name === 'username' ? 'autocapitalize="none" spellcheck="false"' : ''} ${name === 'phone' ? 'inputmode="tel"' : ''} ${name === 'birthday' ? `max="${latestBirthday()}"` : ''} maxlength="${maxLength}" ${name === 'middleName' ? '' : 'required'} aria-invalid="false" aria-describedby="${name}-error${helper ? ` ${name}-helper` : ''}${hasRequirements ? ' password-helper password-requirements password-strength' : ''}">${type === 'password' ? `<button type="button" class="visibility-toggle" data-toggle="${name}" aria-label="Show ${label.toLowerCase()}" aria-pressed="false">${eye}<span>Show</span></button>` : ''}</div>${hasRequirements ? '<p class="helper-text" id="password-helper">Password must contain:</p><ul class="requirements" id="password-requirements">' + passwordRules.map(([key, text, test]) => `<li data-rule="${key}" class="${test(value) ? 'met' : ''}"><span class="sr-only">${test(value) ? 'Met: ' : 'Not met: '}</span>${text}</li>`).join('') + `</ul><div class="password-strength" id="password-strength" data-tone="${strength.tone}" role="progressbar" aria-label="Password strength" aria-valuemin="0" aria-valuemax="4" aria-valuenow="${strength.met}" aria-valuetext="${strength.label}"><div class="strength-copy"><span>Password strength</span><strong id="password-strength-label">${strength.label}</strong></div><div class="strength-track" aria-hidden="true"><span id="password-strength-fill" style="--strength:${strength.met}"></span></div></div>` : ''}<div class="field-feedback">${helper ? `<p class="helper-text" id="${name}-helper">${helper}</p>` : ''}<p class="error-text" id="${name}-error" aria-live="polite"></p></div></div>`;
}
function googleSignInButton() {
  return `<div class="auth-divider"><span>or</span></div><button type="button" class="secondary-button google-signin" data-action="google" aria-describedby="google-demo-note"><svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#4285F4" d="M43.61 24.46c0-1.36-.12-2.66-.35-3.92H24.4v7.43h10.77a9.2 9.2 0 0 1-4 6.04v5.02h6.48c3.8-3.5 5.96-8.67 5.96-14.57Z"/><path fill="#34A853" d="M24.4 44c5.4 0 9.94-1.79 13.25-4.87l-6.48-5.02c-1.79 1.2-4.08 1.92-6.77 1.92-5.21 0-9.63-3.52-11.21-8.25H6.5v5.18A20 20 0 0 0 24.4 44Z"/><path fill="#FBBC05" d="M13.19 27.78a12.03 12.03 0 0 1 0-7.56v-5.18H6.5a20 20 0 0 0 0 17.92l6.69-5.18Z"/><path fill="#EA4335" d="M24.4 11.97c2.94 0 5.58 1.01 7.65 2.99l5.74-5.74A19.22 19.22 0 0 0 24.4 4 20 20 0 0 0 6.5 15.04l6.69 5.18c1.58-4.73 6-8.25 11.21-8.25Z"/></svg><span>Google sign-in (demo)</span></button><p class="google-demo-note" id="google-demo-note">Preview only · Google sign-in isn’t connected.</p>`;
}
function formError() { return '<div class="form-error" id="form-error" role="alert"></div>'; }
function heading(kicker, title, copy) { return `<span class="section-kicker">${kicker}</span><h2 id="view-heading" tabindex="-1">${title}</h2><p class="intro">${copy}</p>`; }
function render(focus = false) {
  document.querySelector('.auth-tabs').hidden = ['confirmation', 'dashboard', 'reset-sent'].includes(state.view);
  document.getElementById('signin-tab').classList.toggle('selected', ['signin', 'reset'].includes(state.view));
  document.getElementById('signup-tab').classList.toggle('selected', state.view === 'signup');
  for (const tab of document.querySelectorAll('.auth-tabs button')) {
    if (tab.classList.contains('selected')) tab.setAttribute('aria-current', 'page'); else tab.removeAttribute('aria-current');
  }
  const journeyIndex = state.view === 'signup' ? 1 : ['confirmation', 'dashboard'].includes(state.view) ? 2 : 0;
  document.querySelectorAll('.journey li').forEach((li, i) => { const button = li.querySelector('.journey-button'); li.classList.toggle('active', i === journeyIndex); li.classList.toggle('complete', i < journeyIndex); if (i === journeyIndex) button?.setAttribute('aria-current', 'step'); else button?.removeAttribute('aria-current'); });
  document.getElementById('form-footnote').innerHTML = '<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="3.5" y="7" width="9" height="7" rx="1.5" stroke="currentColor"/><path d="M5.5 7V4.5a2.5 2.5 0 0 1 5 0V7" stroke="currentColor"/></svg>' + (state.view === 'signup' ? 'Your details stay here until you’re ready.' : 'A private moment. A simple beginning.');
  let html = '';
  if (state.view === 'signin') {
    html = heading('YOUR SPACE AWAITS', 'Welcome back', 'Sign in to continue to your account.') + `<form id="auth-form" novalidate>${formError()}<fieldset><legend class="sr-only">Sign in details</legend>${field('email', 'auth')}${field('password', 'auth')}<div class="form-options"><label class="checkbox-label"><input type="checkbox" name="remember" ${state.auth.remember ? 'checked' : ''}>Remember me</label><button class="inline-link" type="button" data-action="forgot">Forgot password?</button></div><button class="primary-button" type="submit">Sign In ${arrow}</button></fieldset></form>${googleSignInButton()}<p class="signup-prompt">New here?<button class="inline-link" data-action="signup">Create an account ${arrow}</button></p>`;
  } else if (state.view === 'signup') {
    html = renderStepper();
    if (state.step === 1) html += heading('STEP 1 OF 3 · THE ESSENTIALS', 'First, a little about you', 'Let’s get to know the person behind the account.') + '<p class="required-note">Fields marked * are required.</p>';
    if (state.step === 2) html += heading('STEP 2 OF 3 · MAKE IT YOURS', 'Your account, your way', 'Choose how you’ll sign in. We’ll keep it simple.') + '<p class="required-note">Fields marked * are required.</p>';
    if (state.step === 3) html += heading('STEP 3 OF 3 · ONE LAST LOOK', 'Does everything look right?', 'Take a moment to review your details before continuing.');
    html += `<form id="signup-form" novalidate>${formError()}<fieldset><legend class="sr-only">${['Personal details', 'Account details', 'Review your details'][state.step - 1]}</legend>`;
    if (state.step === 1) html += `<div class="two-column">${field('firstName')}${field('lastName')}</div>${field('middleName')}${field('email')}${field('phone')}`;
    if (state.step === 2) html += field('username') + field('hobby') + field('birthday') + field('password') + field('confirmPassword');
    if (state.step === 3) html += renderReview();
    html += `<div class="form-actions"><button type="button" class="secondary-button" data-action="back"><span aria-hidden="true">←</span> Back</button><button type="submit" class="primary-button">${state.step === 3 ? 'Create Account' : state.editing ? 'Save & Review' : 'Continue'} ${arrow}</button></div>${state.step === 3 ? '<p class="demo-notice">This is an interactive demo. No real account will be created.</p>' : ''}</fieldset></form>`;
  } else if (state.view === 'confirmation') {
    html = `<div class="confirmation"><div class="success-symbol" aria-hidden="true">✓</div>${heading('EVERYTHING IS IN PLACE', 'Account created successfully', 'Your account is ready. You can now continue to your dashboard.')}<div class="confirmation-summary"><span>Your account</span><strong>${escapeHTML(state.signup.email)}</strong></div><button class="primary-button" data-action="dashboard">Continue to Dashboard ${arrow}</button><div class="center-action"><button class="inline-link" data-action="home">Back to Home</button></div><p class="demo-notice">Demo complete. Your details were not sent to a server.</p></div>`;
  } else if (state.view === 'dashboard') {
    html = renderDashboard();
  } else if (state.view === 'reset') {
    html = heading('LET’S GET YOU BACK IN', 'Forgot your password?', 'Enter your email address and we’ll walk through the recovery flow.') + `<form id="reset-form" novalidate>${formError()}${field('email', 'reset')}<button class="primary-button" type="submit">Preview recovery ${arrow}</button><p class="demo-notice">Demo only. No recovery email will be sent.</p></form><div class="center-action"><button class="inline-link" data-action="signin">← Back to Sign In</button></div>`;
  } else if (state.view === 'reset-sent') {
    html = `<div class="confirmation"><div class="success-symbol" aria-hidden="true">✓</div>${heading('RECOVERY PREVIEW', 'Your next step, made clear', 'In a connected service, an eligible account would receive a password reset link.')}<p class="review-note">This demo has not sent an email to <strong>${escapeHTML(state.resetEmail)}</strong>. Use the demo credentials to try signing in.</p><button class="primary-button" style="margin-top:28px" data-action="signin">Back to Sign In ${arrow}</button></div>`;
  }
  view.innerHTML = `<div class="view-content">${html}</div>`;
  document.title = `${document.getElementById('view-heading')?.textContent || 'Welcome'} — Forma`;
  bindForm();
  if (focus) requestAnimationFrame(() => {
    const target = state.view === 'signup' && state.step < 3 ? view.querySelector('input') : document.getElementById('view-heading');
    target?.focus({ preventScroll: true });
    if (window.innerWidth <= 720) document.querySelector('.form-region').scrollIntoView({ behavior: 'instant', block: 'start' });
    announce(state.view === 'signup' ? `Step ${state.step} of 3. ${document.getElementById('view-heading').textContent}` : document.getElementById('view-heading').textContent);
  });
}
function renderStepper() {
  return '<ol class="stepper" aria-label="Account setup progress">' + ['Personal Details', 'Account Details', 'Review'].map((label, i) => `<li class="${state.step > i + 1 ? 'done' : ''}"><button type="button" data-step="${i + 1}" ${state.step === i + 1 ? 'aria-current="step"' : ''} ${i + 1 > state.maxStep ? 'disabled' : ''} aria-label="Step ${i + 1}: ${label}${state.step > i + 1 ? ', completed' : state.step === i + 1 ? ', current step' : ', remaining'}"><span class="step-number" aria-hidden="true">${state.step > i + 1 ? '<span>✓</span>' : i + 1}</span>${label}</button></li>`).join('') + '</ol>';
}
function renderReview() {
  const data = state.signup;
  return `<section class="review-section"><div class="review-heading"><h3>Personal Details</h3><button type="button" class="inline-link" data-edit="1" aria-label="Edit personal details">Edit ↗</button></div><dl><dt>Full name</dt><dd>${escapeHTML([data.firstName, data.middleName, data.lastName].filter(Boolean).join(' '))}</dd><dt>Email address</dt><dd>${escapeHTML(data.email)}</dd><dt>Phone number</dt><dd>${escapeHTML(data.phone)}</dd></dl></section><section class="review-section"><div class="review-heading"><h3>Account Details</h3><button type="button" class="inline-link" data-edit="2" aria-label="Edit account details">Edit ↗</button></div><dl><dt>Username</dt><dd>${escapeHTML(data.username)}</dd><dt>Hobby</dt><dd>${escapeHTML(data.hobby)}</dd><dt>Birthday</dt><dd>${escapeHTML(data.birthday)}</dd><dt>Age</dt><dd>${birthdayDetails(data.birthday)?.age ?? '—'} years old</dd><dt>Password</dt><dd>Set · Hidden for your privacy</dd></dl></section><div class="agreement"><div class="agreement-label"><input id="agreement" name="agreement" type="checkbox" ${data.agreement ? 'checked' : ''} aria-invalid="false" aria-describedby="agreement-error"><span><label for="agreement">I agree to the </label><button type="button" class="inline-link" data-action="terms">Terms &amp; Conditions</button> and <button type="button" class="inline-link" data-action="privacy">Privacy Policy</button>.</span></div><p class="error-text" id="agreement-error" aria-live="polite"></p></div>`;
}
function renderDashboard() {
  const name = state.created && state.signup.firstName ? `Welcome, ${escapeHTML(state.signup.firstName)}.` : 'Make yourself at home.';
  if (!state.setup.step) {
    const isComplete = state.setup.complete;
    return `<div class="dashboard"><div class="success-symbol" aria-hidden="true">✓</div>${heading('YOUR DASHBOARD', name, isComplete ? 'Your account setup is complete. You can revisit these demo preferences whenever you need.' : 'You’re signed in to the demo. Finish a few optional details to make this space yours.')}<section class="setup-card" aria-labelledby="setup-card-title"><div><span class="section-kicker">ACCOUNT SETUP · ${isComplete ? 'COMPLETE' : '0 OF 3'}</span><h3 id="setup-card-title">${isComplete ? 'Your account is set up' : 'Set up your account'}</h3><p>${isComplete ? 'Your profile and update preferences are ready.' : 'Personalize your profile, choose update preferences, and review your choices.'}</p></div><button class="primary-button" type="button" data-action="setup-start">${isComplete ? 'Review setup' : 'Start setup'} ${arrow}</button></section><p class="review-note">This is a frontend demo. Setup choices stay in this browser tab and are not sent to a server.</p><button class="inline-link" type="button" data-action="signout">Back to Sign In ${arrow}</button></div>`;
  }
  const labels = ['Profile', 'Preferences', 'Review'];
  const stepper = `<ol class="stepper setup-stepper" aria-label="Account setup progress">${labels.map((label, index) => `<li class="${state.setup.step > index + 1 ? 'done' : ''}"><button type="button" disabled ${state.setup.step === index + 1 ? 'aria-current="step"' : ''}><span class="step-number" aria-hidden="true">${state.setup.step > index + 1 ? '✓' : index + 1}</span>${label}</button></li>`).join('')}</ol>`;
  let content = '';
  if (state.setup.step === 1) content = `${heading('ACCOUNT SETUP · STEP 1 OF 3', 'Make it feel like yours', 'Add a display name for this demo dashboard. You can leave this blank.')}<label for="setup-display-name">Display name <span class="optional-label">(optional)</span></label><input id="setup-display-name" name="displayName" type="text" maxlength="60" autocomplete="nickname" placeholder="How should we greet you?" value="${escapeHTML(state.setup.displayName)}"><p class="helper-text">This is shown only in this browser tab.</p>`;
  if (state.setup.step === 2) content = `${heading('ACCOUNT SETUP · STEP 2 OF 3', 'Choose your updates', 'Tell us what kind of demo messages you would want to see.')}<fieldset class="choice-group"><legend>Update preference</legend><label><input type="radio" name="updates" value="important" ${state.setup.updates === 'important' ? 'checked' : ''}> Important account updates only</label><label><input type="radio" name="updates" value="tips" ${state.setup.updates === 'tips' ? 'checked' : ''}> Account updates and helpful tips</label></fieldset>`;
  if (state.setup.step === 3) content = `${heading('ACCOUNT SETUP · STEP 3 OF 3', 'Review your setup', 'Everything is ready. You can change these preferences later.')}<dl class="setup-review"><dt>Display name</dt><dd>${escapeHTML(state.setup.displayName || 'Not set')}</dd><dt>Updates</dt><dd>${state.setup.updates === 'tips' ? 'Account updates and helpful tips' : 'Important account updates only'}</dd></dl>`;
  return `<div class="dashboard">${stepper}<form id="setup-form" novalidate>${content}<div class="form-actions"><button class="secondary-button" type="button" data-action="setup-back">${state.setup.step === 1 ? 'Cancel' : 'Back'}</button><button class="primary-button" type="submit">${state.setup.step === 3 ? 'Finish setup' : 'Continue'} ${arrow}</button></div></form></div>`;
}
function getError(name, value, context = 'signup') {
  if (name === 'agreement') return value ? '' : 'Accept the Terms & Conditions and Privacy Policy to create your account.';
  const trimmed = value.trim();
  if (name === 'middleName' && !trimmed) return '';
  if (!trimmed) return ({ firstName: 'Enter your first name.', lastName: 'Enter your last name.', email: 'Enter your email address.', phone: 'Enter your phone number.', username: 'Choose a username.', hobby: 'Tell us about a hobby you enjoy.', birthday: 'Enter your birthday.', password: 'Enter your password.', confirmPassword: 'Re-enter your password.' })[name];
  if (name === 'email' && !validEmail(trimmed)) return 'Enter a valid email address.';
  if ((name === 'password' || name === 'confirmPassword') && value.length > 128) return 'Use a password with no more than 128 characters.';
  if (context !== 'signup') return '';
  if (name === 'hobby') {
    if (trimmed.length < 2 || trimmed.length > 60) return 'Use 2–60 characters for your hobby.';
    if (!/[\p{L}]/u.test(trimmed) || !/^[\p{L}\p{M}\p{N} '&,\-]+$/u.test(trimmed)) return 'Use letters, numbers, spaces, apostrophes, hyphens, commas, or &.';
  }
  if (name === 'birthday') {
    const details = birthdayDetails(trimmed);
    if (!details) return 'Enter a valid birthday.';
    if (details.isTodayOrFuture) return 'Your birthday must be before today.';
    if (details.age < 13) return 'You must be at least 13 years old to create an account.';
    if (details.age > 120) return 'Enter a birthday within the last 120 years.';
  }
  if (isNameField(name)) {
    const normalized = normalizeName(value);
    if (normalized.length > 60) return 'Use 60 characters or fewer.';
    if (!nameCharacters.test(normalized)) return 'Numbers aren’t allowed. Use letters.';
    if (!namePattern.test(normalized)) return 'Separate names with spaces, apostrophes or -.';
  }
  if (name === 'email' && ['registered@example.com', 'nash.backup21@gmail.com'].includes(trimmed.toLowerCase())) return 'This email is already registered. Sign in or use another email address.';
  if (name === 'phone' && !validPhone(trimmed)) return 'Check the country code and use 7–15 digits with standard grouping.';
  if (name === 'username' && !/^[a-zA-Z0-9_]{3,24}$/.test(value)) return 'Use 3–24 letters, numbers, or underscores, without spaces.';
  if (name === 'username' && ['admin', 'forma', 'taken'].includes(trimmed.toLowerCase())) return 'This username is already taken. Try a different username.';
  if (name === 'password' && !passwordRules.every(([, , test]) => test(value))) return 'Your password needs to meet all four requirements listed above.';
  if (name === 'confirmPassword' && value !== state.signup.password) return 'Your passwords don’t match. Re-enter the same password.';
  return '';
}
function displayError(name, message) {
  const input = document.getElementById(name);
  const error = document.getElementById(`${name}-error`);
  if (input && error) { input.setAttribute('aria-invalid', String(!!message)); error.textContent = message; }
}
function validate(names, context = state.view === 'signin' ? 'auth' : state.view === 'reset' ? 'reset' : 'signup') {
  let firstInvalid;
  names.forEach(name => {
    const value = context === 'reset' ? state.resetEmail : state[context][name];
    const message = getError(name, value, context);
    displayError(name, message);
    if (message && !firstInvalid) firstInvalid = document.getElementById(name);
  });
  if (firstInvalid) { firstInvalid.focus(); announce('Please check the highlighted fields before continuing.'); return false; }
  return true;
}
function bindForm() {
  const form = view.querySelector('form');
  if (!form) return;
  if (form.id === 'setup-form') {
    form.addEventListener('input', e => {
      if (e.target.name === 'displayName') state.setup.displayName = e.target.value;
    });
    form.addEventListener('change', e => {
      if (e.target.name === 'updates') state.setup.updates = e.target.value;
    });
    form.addEventListener('submit', e => {
      e.preventDefault();
      if (state.setup.step < 3) { state.setup.step++; render(true); }
      else { state.setup.step = 0; state.setup.complete = true; render(true); showSuccessToast('Account setup complete', 'Your demo preferences are ready.'); }
    });
    return;
  }
  const context = form.id === 'auth-form' ? 'auth' : form.id === 'reset-form' ? 'reset' : 'signup';
  function save(input) {
    if (context === 'signup') capitalizeNameInput(input);
    if (context === 'signup' && input.name === 'phone') { savePhone(input.value); return; }
    if (context === 'reset') state.resetEmail = input.value;
    else state[context][input.name] = input.type === 'checkbox' ? input.checked : input.value;
  }
  form.addEventListener('change', e => {
    if (e.target.id !== 'phone-country') return;
    state.signup.phoneCountry = e.target.value;
    savePhone(document.getElementById('phone').value);
    updatePhoneCountryUI();
    if (document.getElementById('phone').getAttribute('aria-invalid') === 'true') displayError('phone', getError('phone', state.signup.phone));
  });
  function restrictNameInput(input) {
    if (context !== 'signup' || !isNameField(input.name) || nameCharacters.test(input.value)) return false;
    // Fallback for mobile keyboards, autofill, drop, and non-cancellable edits.
    const caret = input.selectionStart;
    const beforeCaret = input.value.slice(0, caret ?? input.value.length);
    input.value = input.value.replace(/[^\p{L}\p{M} '’\-]/gu, '');
    if (caret !== null) {
      const position = beforeCaret.replace(/[^\p{L}\p{M} '’\-]/gu, '').length;
      input.setSelectionRange(position, position);
    }
    save(input);
    displayError(input.name, nameInputMessage);
    return true;
  }
  form.addEventListener('beforeinput', e => {
    const input = e.target;
    if (!(input instanceof HTMLInputElement) || context !== 'signup' || !isNameField(input.name) || e.isComposing || !e.cancelable) return;
    if (e.data && !nameCharacters.test(e.data)) {
      e.preventDefault();
      displayError(input.name, nameInputMessage);
    }
  });
  form.addEventListener('paste', e => {
    const input = e.target;
    if (!(input instanceof HTMLInputElement) || context !== 'signup' || !isNameField(input.name)) return;
    const pasted = e.clipboardData?.getData('text');
    if (pasted && !nameCharacters.test(pasted)) {
      e.preventDefault();
      displayError(input.name, nameInputMessage);
    }
  });
  form.addEventListener('compositionend', e => {
    if (e.target instanceof HTMLInputElement) {
      if (!restrictNameInput(e.target)) save(e.target);
    }
  });
  form.addEventListener('input', e => {
    if (!(e.target instanceof HTMLInputElement) || e.isComposing) return;
    const input = e.target;
    if (restrictNameInput(input)) return;
    save(input);
    if (document.getElementById('form-error')) document.getElementById('form-error').textContent = '';
    if (input.getAttribute('aria-invalid') === 'true') displayError(input.name, getError(input.name, input.name === 'phone' ? state.signup.phone : input.value, context));
    if (context === 'signup' && input.name === 'birthday') {
      const helper = document.getElementById('birthday-helper');
      if (helper) helper.textContent = birthdayHelper(input.value);
    }
    if (context === 'auth' && document.getElementById('password-error')?.textContent === 'The email or password you entered is incorrect.') displayError('password', '');
    if (context === 'signup' && input.name === 'password') {
      passwordRules.forEach(([key, , test]) => { const item = document.querySelector(`[data-rule="${key}"]`); item.classList.toggle('met', test(input.value)); item.querySelector('.sr-only').textContent = test(input.value) ? 'Met: ' : 'Not met: '; });
      const strength = passwordStrength(input.value);
      const meter = document.getElementById('password-strength');
      if (meter) {
        meter.dataset.tone = strength.tone;
        meter.setAttribute('aria-valuenow', String(strength.met));
        meter.setAttribute('aria-valuetext', strength.label);
        document.getElementById('password-strength-label').textContent = strength.label;
        document.getElementById('password-strength-fill').style.setProperty('--strength', strength.met);
      }
      if (document.getElementById('confirmPassword')?.getAttribute('aria-invalid') === 'true') displayError('confirmPassword', getError('confirmPassword', state.signup.confirmPassword));
    }
  });
  form.addEventListener('focusout', e => {
    if (e.target instanceof HTMLInputElement && e.target.type !== 'checkbox' && !state.pending) {
      if (isNameField(e.target.name)) e.target.value = normalizeName(e.target.value);
      save(e.target);
      displayError(e.target.name, getError(e.target.name, e.target.name === 'phone' ? state.signup.phone : e.target.value, context));
    }
  });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (state.pending) return;
    form.querySelectorAll('input').forEach(save); // Also capture browser autofill.
    if (context === 'auth') {
      if (!validate(['email', 'password'], context)) return;
      await submitDemo(form, 'Signing in…', () => {
        if (state.auth.email.trim().toLowerCase() !== 'nash.backup21@gmail.com' || state.auth.password !== 'password') { displayError('password', 'The email or password you entered is incorrect.'); document.getElementById('password').focus(); return; }
        try { if (state.auth.remember) localStorage.setItem('forma-remembered-email', state.auth.email.trim()); else localStorage.removeItem('forma-remembered-email'); } catch (_) {}
        state.auth.password = ''; state.signedIn = true;
        if (state.created) resetSignup();
        navigate('dashboard');
        showSuccessToast('Signed in successfully', 'Your dashboard is ready.');
      });
    } else if (context === 'reset') {
      if (!validate(['email'], 'reset')) return;
      await submitDemo(form, 'Preparing preview…', () => navigate('reset-sent'));
    } else if (state.step < 3) {
      if (!validate(groups[state.step], 'signup')) return;
      if (state.step === 1) {
        state.signup.firstName = normalizeName(state.signup.firstName);
        state.signup.middleName = normalizeName(state.signup.middleName);
        state.signup.lastName = normalizeName(state.signup.lastName);
        state.signup.email = state.signup.email.trim();
        state.signup.phone = state.signup.phone.trim();
      }
      if (state.step === 2) state.signup.hobby = state.signup.hobby.trim().replace(/\s+/g, ' ');
      if (state.editing) { state.editing = false; state.step = 3; }
      else { state.step++; state.maxStep = Math.max(state.maxStep, state.step); }
      render(true);
    } else {
      if (!validate(['agreement'], 'signup')) return;
      // Revalidate both steps before the final simulated submission.
      for (const step of [1, 2]) {
        if (groups[step].some(name => getError(name, state.signup[name]))) { state.step = step; render(); validate(groups[step], 'signup'); return; }
      }
      await submitDemo(form, 'Creating your account…', () => { state.created = true; state.signedIn = true; state.signup.password = ''; state.signup.confirmPassword = ''; navigate('confirmation'); showSuccessToast('Account created successfully', 'Your demo account setup is complete.'); });
    }
  });
}
async function submitDemo(form, label, onSuccess) {
  state.pending = true;
  const button = form.querySelector('[type="submit"]');
  const original = button.innerHTML;
  const controls = [...document.querySelectorAll('main button, main input, main select, .site-header button')];
  const priorDisabled = controls.map(control => control.disabled);
  controls.forEach(control => { control.disabled = true; });
  button.innerHTML = `<span class="spinner" aria-hidden="true"></span>${label}`;
  form.setAttribute('aria-busy', 'true');
  announce(label);
  const scenario = state.scenario;
  await new Promise(resolve => setTimeout(resolve, scenario === 'timeout' ? 2400 : 1000));
  controls.forEach((control, i) => { control.disabled = priorDisabled[i]; });
  button.innerHTML = original;
  form.removeAttribute('aria-busy');
  state.pending = false;
  const messages = {
    network: 'We couldn’t connect. Please check your internet connection and try again. Your details are still here.',
    server: 'The account service is temporarily unavailable. Please try again in a moment. Your details are still here.',
    timeout: 'The request took too long. Please try again. Your details are still here and no action was completed.'
  };
  if (messages[scenario]) {
    state.scenario = 'normal'; // Transient demo failures are recoverable with a simple retry.
    document.getElementById('form-error').textContent = messages[scenario];
    button.focus();
  } else onSuccess();
}
let toastTimer;
function showSuccessToast(title, description) {
  const toast = document.getElementById('success-toast');
  clearTimeout(toastTimer);
  document.getElementById('toast-title').textContent = title;
  document.getElementById('toast-description').textContent = description;
  toast.hidden = false;
  toastTimer = setTimeout(() => { toast.hidden = true; }, 8000);
}
document.getElementById('toast-dismiss').addEventListener('click', () => {
  clearTimeout(toastTimer);
  document.getElementById('success-toast').hidden = true;
});
document.getElementById('success-toast').addEventListener('mouseenter', () => clearTimeout(toastTimer));
document.getElementById('success-toast').addEventListener('focusin', () => clearTimeout(toastTimer));
function announce(message) { announcer.textContent = ''; requestAnimationFrame(() => { announcer.textContent = message; }); }
function navigate(next) { state.view = next; render(true); }
function resetSignup() { state.signup = { firstName: '', middleName: '', lastName: '', email: '', phone: '', phoneCountry: 'PH', phoneNational: '', username: '', hobby: '', birthday: '', password: '', confirmPassword: '', agreement: false }; state.setup = { step: 0, complete: false, displayName: '', updates: 'important' }; state.step = 1; state.maxStep = 1; state.created = false; state.editing = false; }
document.addEventListener('click', e => {
  const toggle = e.target.closest('[data-toggle]');
  if (toggle && !state.pending) {
    const input = document.getElementById(toggle.dataset.toggle);
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    toggle.querySelector('span').textContent = show ? 'Hide' : 'Show';
    toggle.setAttribute('aria-label', `${show ? 'Hide' : 'Show'} ${definitions[input.name][0].toLowerCase()}`);
    toggle.setAttribute('aria-pressed', String(show));
    return;
  }
  const stepButton = e.target.closest('[data-step], [data-edit]');
  if (stepButton && !state.pending) {
    const target = Number(stepButton.dataset.step || stepButton.dataset.edit);
    if (target > state.maxStep || target === state.step) return;
    if (target > state.step && state.step < 3 && !validate(groups[state.step], 'signup')) return;
    state.editing = !!stepButton.dataset.edit;
    state.step = target; render(true); return;
  }
  const action = e.target.closest('[data-action]')?.dataset.action;
  if (!action || (state.pending && !['demo', 'privacy', 'terms', 'help'].includes(action))) return;
  switch (action) {
    case 'journey-auth': navigate('signin'); break;
    case 'journey-setup':
      if (state.signedIn || state.created) { state.setup.complete = false; state.setup.step = 1; navigate('dashboard'); }
      else navigate('signup');
      break;
    case 'journey-ready':
      if (state.signedIn || state.created) navigate('dashboard');
      else openDialog('journey-ready');
      break;
    case 'signin': navigate('signin'); break;
    case 'signup': if (state.created) resetSignup(); navigate('signup'); break;
    case 'forgot': state.resetEmail = state.auth.email; navigate('reset'); break;
    case 'back': state.editing = false; if (state.step > 1) { state.step--; render(true); } else navigate('signin'); break;
    case 'dashboard': navigate('dashboard'); break;
    case 'setup-start': state.setup.complete = false; state.setup.step = 1; render(true); break;
    case 'setup-back':
      if (state.setup.step > 1) state.setup.step--;
      else state.setup.step = 0;
      render(true);
      break;
    case 'signout': state.signedIn = false; state.auth.password = ''; resetSignup(); navigate('signin'); break;
    case 'home': resetSignup(); state.signedIn = false; navigate('signin'); break;
    default: openDialog(action);
  }
});
const dialog = document.getElementById('info-dialog');
document.getElementById('dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', e => { if (e.target === dialog) { const rect = dialog.getBoundingClientRect(); if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) dialog.close(); } });
function openDialog(kind) {
  const contents = {
    google: ['Google sign-in isn’t connected', '<p>This button previews the Google sign-in option. It does not access your Google account or sign you in.</p><p>Real Google sign-in requires a configured Google authentication service with secure verification. For now, use your demo email and password.</p><button type="button" class="primary-button" id="google-use-email">Use email instead</button>'],
    'journey-ready': ['Finish your account journey', '<p>Sign in or create an account first. Once you are signed in, this step takes you to your dashboard.</p><button type="button" class="primary-button" id="journey-signin">Go to Sign in</button>'],
    help: ['A little guidance', '<p>New to Forma? Choose <strong>Create account</strong> to try the three-step onboarding. Already exploring? Use the sample sign-in in Interactive demo.</p><p>This is a frontend demonstration. There is no connected support service or real account system.</p><button class="primary-button" id="open-demo">View demo details →</button>'],
    privacy: ['Privacy Policy', '<p><strong>Demo data:</strong> this experience does not send form entries to a server. Details remain in page memory and clear when the page reloads. Passwords are never saved to browser storage.</p><p><strong>Remember me:</strong> after a successful demo sign-in, only the email address may be saved in this browser. It does not keep you signed in. Uncheck Remember me and sign in again to remove it.</p><p><strong>Third parties:</strong> Google Fonts and public country-flag images may load as interface assets. A production service requires a complete, jurisdiction-appropriate privacy policy and secure backend.</p>'],
    terms: ['Terms & Conditions', '<p>Forma is an interactive frontend demonstration. It does not create real accounts, send emails, or provide a secure authenticated session.</p><p>Please enter sample information only. Do not enter sensitive, financial, or personally identifying information.</p><p>By continuing in this demo, you acknowledge that no account is created and that these are demo terms, not a production service agreement.</p>'],
    demo: ['Try the experience', `<p>This is a frontend demo, not a real authentication service. Use sample details to explore the flow.</p><p><strong>Sample sign-in</strong><br>Email: <code>nash.backup21@gmail.com</code><br>Password: <code>password</code></p><p>To test an existing account, enter <code>registered@example.com</code> during onboarding. Try <code>admin</code> for a taken username.</p><label for="demo-scenario">Next submission outcome</label><select id="demo-scenario" ${state.pending ? 'disabled' : ''}><option value="normal">Normal behavior</option><option value="network">Network connection error</option><option value="server">Server temporarily unavailable</option><option value="timeout">Submission timeout</option></select><p class="helper-text">Applies to the next sign-in, account creation, or recovery action. Simulated failures reset automatically so you can retry.</p><button class="primary-button" id="demo-done">${state.pending ? 'Close' : 'Save & close'}</button>`]
  };
  if (!contents[kind]) return;
  document.getElementById('dialog-title').textContent = contents[kind][0];
  document.getElementById('dialog-content').innerHTML = contents[kind][1];
  if (!dialog.open) dialog.showModal();
  if (kind === 'google') document.getElementById('google-use-email').onclick = () => { dialog.close(); document.getElementById('email')?.focus(); };
  if (kind === 'journey-ready') document.getElementById('journey-signin').onclick = () => { dialog.close(); navigate('signin'); };
  if (kind === 'help') document.getElementById('open-demo').onclick = () => openDialog('demo');
  if (kind === 'demo') {
    document.getElementById('demo-scenario').value = state.scenario;
    document.getElementById('demo-done').onclick = () => { if (!state.pending) state.scenario = document.getElementById('demo-scenario').value; dialog.close(); };
  }
}
// Only public, non-sensitive entry states are available through a query parameter.
const initialView = new URLSearchParams(location.search).get('view');
if (initialView === 'signup' || initialView === 'reset') state.view = initialView;
render();
// Explicit QA entry renders the real application at the browser's actual viewport.
if (initialView === 'signup' && new URLSearchParams(location.search).get('feedback') === 'errors') {
  const qaScript = document.createElement('script');
  qaScript.src = 'tests/validation-state.js';
  document.body.appendChild(qaScript);
}
