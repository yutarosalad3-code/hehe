# Forma — a considered account experience

## Purpose and design
A static, frontend-only account flow prioritizing usability, editorial typography, understated visual hierarchy, and responsive layouts. Instrument Serif headings pair with Inter interface text; warm neutrals and one forest-green accent keep the interface calm. No framework or build step is required.

## Completed features
- Desktop journey panel uses sticky positioning at the viewport top, aligned to the start of the main grid with a 100svh height. It can scroll internally on short screens, remains bounded by the main section above the footer, and does not change the existing hidden-on-mobile layout. This CSS-only change has not been browser-verified; no tests were run.
- Header height reduced from 100px to 64px on desktop and from 80px to 60px on mobile. Main-area viewport calculations adjusted to match. No tests or screenshots run for this header-only change, as requested.
- Google sign-in preview button with a Google icon and restrained divider below email sign-in. It is visibly labeled as a demo, opens an explanatory dialog with Use email instead, preserves input and returns focus. It never simulates Google authorization or sets a signed-in session.
- Compact sign-in with visible labels, exact required/invalid-email messages, password visibility toggle, remember-email option, credential errors, stable-width loading button, and duplicate-submission prevention.
- Connected three-step onboarding: Personal Details → Account Details → Review. Create account opens this flow directly.
- Successful demo sign-in opens the dashboard. From there, an optional three-step account-setup flow collects a display name, update preference, and a final review; these demo-only choices remain in memory.
- Optional Middle name is included in review and preserved when editing. All name fields capitalize the first letter of each name part while typing, without lowercasing intentional internal capitals. Required fields have visible * markers; Middle name is explicitly labeled optional.
- First/middle/last name input blocks numbers and disallowed symbols in typing and paste, with an input fallback for mobile/autofill and IME-aware handling. Names allow Unicode letters/marks, spaces, apostrophes, and hyphens; validation also checks structure and a 60-character maximum.
- Phone field includes a keyboard-accessible native country dropdown with visible flag/calling code, defaulting to Philippines (+63). Option text now begins with the country name, with the flag after the calling code, enabling native keyboard type-ahead (for example A → Australia) instead of matching a leading emoji. The closed selector still shows the flag and calling code. This label-only change was saved without a new browser test. Includes 24 country choices, preserves selection and national number between steps, and splits pasted supported international numbers without duplicating the prefix.
- Visible current/completed/remaining steps; backward navigation preserves entries; current-step validation blocks invalid progression.
- Four live password requirements, password confirmation, username constraints, simulated existing-user and email conflicts.
- Review grouped by section, direct Edit actions, Save & Review, and no exposed password.
- Dismissible success toasts appear after successful demo login and account creation. Toasts are fixed overlays and do not move the form; they expire after eight seconds unless hovered/focused.
- Helper text and inline validation now occupy the same compact `field-feedback` grid slot instead of stacking helper text above a separate reserved error block. Errors replace helpers visually, with associations preserved. The slot reserves 16px in onboarding and desktop sign-in, with 32px retained for other contexts. Longer messages wrap naturally rather than being clipped; they may require additional height. Password requirements stay visible separately.
- Both forms now use 6px field margins. Onboarding feedback spacing is 4px with an 8px action margin; sign-in feedback spacing is 5px with an 8px options-to-sign-in gap. This latest onboarding-only tightening was saved without tests or screenshots, as requested. Inputs remain 48px high. Existing oversized error-space rules were replaced rather than layered with more overrides.
- Calm account-created confirmation, a Continue to Dashboard action, and a minimal demo destination (not a fabricated analytics dashboard).
- Recovery preview, privacy/terms information, and contextual help dialogs.
- Footer Interactive demo controls for recoverable network, server, and timeout failures. Each injected failure applies once; retry returns to normal behavior.
- Field-level errors associated with inputs using aria-invalid/aria-describedby, live announcements, first-invalid focus, next-step autofocus, keyboard-operable controls, semantic form grouping, native modal focus management, visible focus indicators, and reduced-motion support.
- Responsive split layout on desktop; focused single-column experience with 24px gutters on phones; 48px inputs and primary controls; no mobile input zoom.

## Functional entry URIs
- `/` or `/index.html`: sign-in, with connected flow controlled in memory.
- `/index.html?view=signup`: begin onboarding.
- `/signup.html`: redirects to the canonical onboarding entry above.
- `/index.html?view=reset`: password recovery preview.
- `/tests/flow.html`: automated DOM interaction regression suite against the actual application in an iframe. Not a substitute for actual mobile screenshots.
- Review, confirmation, and demo dashboard are in-page states reached by completing the flow; they do not have independent authenticated routes.

## Running and publishing
Open the project preview or serve the project from an ordinary static HTTP host. No installation, build, or API configuration is needed.

No production URL has been assigned, and this project has not been Hosted-Deployed. Use the Publish tab to publish when ready.

## Demo credentials and error cases
- Successful sign-in: `nash.backup21@gmail.com` / `password` (public demo credentials only; not a secure login).
- Any other well-formed sign-in credentials produce the specified incorrect-credentials message.
- Existing onboarding emails: `registered@example.com`, `nash.backup21@gmail.com`.
- Unavailable usernames: `admin`, `forma`, `taken` (case-insensitive).
- Username: 3–24 ASCII letters, digits, or underscores.
- Names: Middle name may be blank. When entered, all name fields allow 1–60 characters after trimming/normalizing spaces; Unicode letters, spaces, apostrophes, and hyphens. Must start/end with a letter (combining marks permitted). Punctuation must separate name parts; no digits or arbitrary symbols.
- Email: maximum 254 characters, local part maximum 64, no repeated/leading/trailing local dots, valid domain labels and a multi-character top-level domain. Format validation does not establish mailbox ownership.
- Phone: choose a country code and enter the national number separately (e.g. Philippines +63 and 917 123 4567). The combined value is checked for 7–15 digits total and normal formatting, with a maximum of 32 formatted characters. This is format validation, not country-specific numbering-plan or subscription verification.
- New-account password: 8–128 characters, uppercase, lowercase, and a number; confirmation must match exactly. Explicit limits are also checked when browser maxlength is bypassed.
- Network/server failures resolve after a simulated 1 second. Simulated timeout resolves after 2.4 seconds for convenient testing; this is not an actual production request timeout.
- Use sample personal details only.

## Data models and storage
- `state.auth`: email, password, remember preference.
- `state.signup`: firstName, middleName, lastName, email, phone (combined international value), phoneCountry (ISO country code, default PH), phoneNational (separate national entry), username, hobby, birthday, password, confirmPassword, agreement.
- Flow metadata: current view/step, furthest step, editing flag, pending flag, scenario, and demo completion state.
- Form entries are retained only in JavaScript memory and are discarded on reload. Passwords are cleared after successful completion and are never written to browser storage, logs, URLs, or any table.
- The optional localStorage key `forma-remembered-email` saves only the successful demo sign-in email. It does **not** persist a session. Unchecking Remember me and signing in again removes the saved email.
- No database, Table API, authentication provider, cookies, or backend is connected. No personal form data is transmitted. External UI assets are Google Fonts and public country flag SVGs from FlagCDN; no personal form data is included in those asset requests.
- No public application API endpoints exist.

## Verification
- Prior version: browser-based interaction suite passed 37 assertions, covering required/email errors, error correction, focus management, password visibility, loading lock, incorrect/successful sign-in, recovery honesty, current-step validation, email/username conflicts, password strength/mismatch, review edits, password privacy, all three simulated failure modes, successful retry, confirmation/destination, and clearing a completed flow.
- Desktop and mobile sign-in screenshots verified layout and no horizontal overflow.
- Desktop and mobile onboarding screenshots verified labels, readable progress, side-by-side name inputs, alignment, actions, footer fit, and no horizontal overflow.
- Latest revision: expanded regression coverage for name input prevention, paste, IME, Unicode names, input bypasses, stronger email/phone/username/password rules, sign-in → dashboard navigation, and dashboard account setup. The latest browser harness attempt returned no result in this environment; the JavaScript syntax check passed.
- Country-dropdown revision: desktop and actual mobile screenshots confirmed the Philippines flag, +63, national-number input, readable labels, and no clipping/overflow. The full regression suite was not rerun.
- Most recent completed interaction run: all 99 assertions passed, including optional middle name, capitalization, updated demo credentials, both success toasts, and stable input/form dimensions for required errors in the regression harness. Subsequent desktop/mobile error-state screenshot requests returned no result. All further testing was stopped when requested by the user; the latest populated-error layout is not visually reverified.
- `/tests/validation.html` redirects to `/index.html?view=signup&feedback=errors`, a QA entry showing inline errors on the actual application. `tests/validation-state.js` checks layout dimensions only when that explicit entry is opened.
- Latest spacing revision: actual sign-in and onboarding screenshots at both desktop and mobile widths confirmed compact gaps, readable helpers/labels, and no overlap or horizontal overflow. The Google button is visible in the current sign-in. No full interaction-suite rerun was performed for this spacing revision.
- Manual assistive-technology testing remains recommended; do not treat automated checks as a full WCAG certification.

## Not implemented / limitations
- Google OAuth / Google Identity Services configuration, secure token verification, and Google account sessions are not implemented. The Google button is a disclosed UI placeholder only.
- Real account creation, secure sign-in, server-side authorization, email delivery, real availability checks, rate limits, session management, and persistent account records.
- A real application dashboard and production legal/support services.
- Authentication cannot be secured by a static client-side credential check. The exposed credentials and demo state are intentionally not security mechanisms.
- Refresh does not resume incomplete onboarding; this deliberately avoids saving sensitive data locally.

## Recommended next steps
1. Connect the interface to a separately implemented secure authentication service using appropriate server-side credential handling, sessions, abuse protections, and verified email recovery.
2. Configure Google sign-in with an appropriate secure authentication provider in a backend-capable environment before enabling the Google button for real authentication. Replace demo collisions and failure simulation with real API responses, cancellation, and request timeouts.
3. Add production legal copy and a real support destination.
4. Run keyboard, screen-reader, contrast, reduced-motion, and cross-browser testing with representative users.
5. If production needs onboarding resumption, define a privacy-conscious storage strategy without storing passwords in the browser.

## Files
- `index.html`: application shell and semantic structure.
- `css/style.css`: design tokens, desktop/mobile layouts, control states, and motion.
- `js/app.js`: rendering, validation, form lifecycle, accessibility, dialogs, and demo simulation.
- `signup.html`: onboarding entry redirect.
- `tests/flow.html`, `tests/flow.js`: regression harness.
# hehe
