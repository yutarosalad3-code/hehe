'use strict';
const frame = document.getElementById('app');
const results = document.getElementById('results');
const sleep = ms => new Promise(r => setTimeout(r, ms));
frame.addEventListener('load', async () => {
  const w = frame.contentWindow, d = frame.contentDocument;
  let count = 0;
  const check = (condition, label) => { if (!condition) throw new Error(label); count++; console.log(`PASS ${count}: ${label}`); results.textContent += `\nPASS: ${label}`; };
  const click = selector => { const target = d.querySelector(selector); if (!target) throw new Error(`Missing ${selector}`); target.click(); };
  const fill = (name, value, blur = false) => { const input = d.getElementById(name); input.value = value; input.dispatchEvent(new w.Event('input', { bubbles: true })); if (blur) input.dispatchEvent(new w.FocusEvent('focusout', { bubbles: true })); };
  const submit = () => d.querySelector('form').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  const text = selector => d.querySelector(selector)?.textContent || '';
  results.textContent = '';
  try {
    check(!!d.querySelector('#auth-form'), 'Authentication loads');
    fill('email', ''); submit();
    check(text('#email-error') === 'Enter your email address.', 'Required email has contextual error');
    check(d.activeElement.id === 'email', 'First invalid field receives focus');
    fill('email', 'invalid');
    check(text('#email-error') === 'Enter a valid email address.', 'Existing email error updates while correcting');
    fill('email', 'nash.backup21@gmail.com'); fill('password', 'wrong');
    click('[data-toggle="password"]'); check(d.getElementById('password').type === 'text', 'Show password works');
    click('[data-toggle="password"]'); check(d.getElementById('password').type === 'password', 'Hide password works');
    submit(); check(d.querySelector('[type="submit"]').disabled, 'Submission is disabled while loading');
    submit(); await sleep(1150);
    check(text('#password-error').includes('email or password you entered is incorrect'), 'Incorrect credentials show field error');
    check(d.getElementById('password').value === 'wrong', 'Failed sign-in preserves password');
    fill('password', 'password'); submit(); await sleep(1150);
    check(text('#view').includes('Set up your account'), 'Successful sign-in opens the dashboard');
    check(!d.getElementById('success-toast').hidden && text('#toast-title') === 'Signed in successfully', 'Sign-in shows the success toast');
    click('#toast-dismiss');
    check(d.getElementById('success-toast').hidden, 'Success toast is dismissible');
    click('[data-action="setup-start"]');
    check(!!d.querySelector('#setup-form') && text('#view').includes('STEP 1 OF 3'), 'Dashboard account setup starts with a three-step flow');
    fill('setup-display-name', 'Nash'); submit();
    check(text('#view').includes('STEP 2 OF 3'), 'Dashboard setup progresses to preferences');
    click('[data-action="setup-back"]'); click('[data-action="setup-back"]');
    click('[data-action="signout"]'); click('[data-action="forgot"]'); fill('email', 'sample@example.com'); submit(); await sleep(1150);
    check(text('#view').includes('has not sent an email'), 'Recovery truthfully explains demo outcome');
    click('#view [data-action="signin"]'); click('[data-action="signup"]'); await sleep(40);
    check(d.activeElement.id === 'firstName', 'First onboarding field gets focus');
    check(!d.getElementById('middleName').required && text('label[for="middleName"]').includes('optional'), 'Middle name is explicitly optional');
    const beforeErrorsHeight = d.querySelector('#signup-form').getBoundingClientRect().height;
    const beforeInputSize = d.getElementById('firstName').getBoundingClientRect();
    submit(); check(d.activeElement.id === 'firstName', 'Step cannot advance with required fields missing');
    check(d.querySelector('#signup-form').getBoundingClientRect().height === beforeErrorsHeight, 'Showing required errors does not change form height');
    check(d.getElementById('firstName').getBoundingClientRect().height === beforeInputSize.height, 'Input height stays stable during errors');
    fill('middleName', '', true); check(!text('#middleName-error'), 'Blank optional middle name is valid');
    fill('middleName', 'marie claire'); check(d.getElementById('middleName').value === 'Marie Claire', 'Middle name auto-capitalizes while typing');
    fill('firstName', 'mary-jane'); check(d.getElementById('firstName').value === 'Mary-Jane', 'Hyphenated names auto-capitalize');
    fill('lastName', "o’neill"); check(d.getElementById('lastName').value === 'O’Neill', 'Surname auto-capitalizes after apostrophes');
    fill('middleName', '');
    // Name restrictions cover keyboard input, paste, mobile fallback, and bypass attempts.
    fill('firstName', 'Alex');
    for (const char of ['1', '٩', '９', '@', '🙂']) {
      const event = new w.InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: char });
      d.getElementById('firstName').dispatchEvent(event);
      check(event.defaultPrevented && d.getElementById('firstName').value === 'Alex', `Name typing blocks ${char} without erasing existing text`);
    }
    const deletion = new w.InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'deleteContentBackward' });
    d.getElementById('firstName').dispatchEvent(deletion);
    check(!deletion.defaultPrevented, 'Name restrictions do not interfere with deletion');
    const clipboard = new w.DataTransfer(); clipboard.setData('text/plain', 'Rivera123');
    const paste = new w.ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: clipboard });
    d.getElementById('lastName').dispatchEvent(paste);
    check(paste.defaultPrevented, 'Mixed numeric pasted names are rejected with feedback');
    fill('lastName', 'Ri9vera@');
    check(d.getElementById('lastName').value === 'Rivera' && text('#lastName-error').includes('weren’t added'), 'Mobile/autofill fallback removes invalid characters with feedback');
    for (const sample of ['María-José', 'O’Neill', "D'Angelo", 'De la Cruz', '李', 'Jose\u0301', 'अनन्या']) {
      fill('firstName', sample, true);
      check(!text('#firstName-error'), `Name validation accepts ${sample}`);
    }
    fill('firstName', '  María   José  ', true);
    check(d.getElementById('firstName').value === 'María José', 'Name spaces are normalized on blur');
    for (const sample of ['---', '-Alex', 'Alex-', "O''Neill", 'A'.repeat(61)]) {
      fill('firstName', sample, true);
      check(!!text('#firstName-error'), `Invalid name structure or length is rejected (${sample.slice(0, 12)})`);
    }
    // Composition must not be disrupted before the user commits their text.
    const compositionInput = d.getElementById('firstName');
    compositionInput.value = '李1';
    compositionInput.dispatchEvent(new w.InputEvent('input', { bubbles: true, isComposing: true, data: '李1' }));
    check(compositionInput.value === '李1', 'Active IME composition is not modified');
    compositionInput.dispatchEvent(new w.CompositionEvent('compositionend', { bubbles: true, data: '李1' }));
    check(compositionInput.value === '李', 'Committed IME input is checked');
    fill('lastName', 'Rivera'); fill('email', 'alex@example.com'); fill('phone', '+63 917 123 4567');
    d.getElementById('firstName').value = 'Alex123'; // Simulate autofill without input events.
    submit();
    check(!!d.getElementById('firstName') && text('#firstName-error').includes('Numbers'), 'Submit validation rejects a name even if input prevention is bypassed');
    check(d.activeElement.id === 'firstName', 'Invalid bypassed name receives focus');
    fill('firstName', 'Alex');
    for (const email of ['a..b@example.com', '.alex@example.com', 'alex@example..com', 'alex@-example.com', 'alex@example.c', 'alex@@example.com']) {
      fill('email', email, true);
      check(text('#email-error') === 'Enter a valid email address.', `Malformed email rejected: ${email}`);
    }
    fill('email', 'alex+test@example.co.uk', true);
    check(!text('#email-error'), 'Plus-addressing and multi-part email domains are accepted');
    for (const phone of ['number', '+0123456789', '+63abc9171234', '+63 123', '+1234567890123456', '+63 ((917)) 1234567', '+63--9171234567']) {
      fill('phone', phone, true);
      check(!!text('#phone-error'), `Invalid phone rejected: ${phone}`);
    }
    fill('phone', '917 123 4567', true);
    check(!text('#phone-error'), 'National number uses the selected Philippines prefix');
    const countrySelect = d.getElementById('phone-country');
    countrySelect.value = 'GB'; countrySelect.dispatchEvent(new w.Event('change', { bubbles: true }));
    check(text('#phone-country-code') === '+44' && d.getElementById('phone').value === '917 123 4567', 'Country change updates code without clearing national number');
    fill('phone', '+1 (415) 555-2671', true);
    check(d.getElementById('phone-country').value === 'US' && d.getElementById('phone').value === '(415) 555-2671', 'Pasted international number updates country without duplicating code');
    check(!text('#phone-error'), 'International number with normal grouping is accepted');
    fill('firstName', 'Alex'); fill('lastName', 'Rivera'); fill('email', 'registered@example.com', true); fill('phone', '+63 917 123 4567');
    check(text('#email-error').includes('already registered'), 'Existing email has actionable message');
    fill('email', 'alex@example.com'); submit(); await sleep(40);
    check(!!d.getElementById('username'), 'Valid personal details advance to account details');
    check(d.activeElement.id === 'username', 'Next step receives focus');
    for (const username of ['ab', 'a'.repeat(25), 'alex name', ' alex ', 'alex@name']) {
      fill('username', username, true);
      check(!!text('#username-error'), `Invalid username rejected: ${username.slice(0, 12)}`);
    }
    fill('password', 'A1a'.repeat(43), true);
    check(text('#password-error').includes('128'), 'Overlong password is rejected even when maxlength is bypassed');
    fill('username', 'admin', true); check(text('#username-error').includes('already taken'), 'Taken username is detected');
    fill('username', 'alex_rivera');
    fill('hobby', '$$$', true); check(!!text('#hobby-error'), 'Hobby rejects unsupported characters');
    fill('hobby', '3D printing', true); check(!text('#hobby-error'), 'Hobby accepts a descriptive value');
    const now = new w.Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    fill('birthday', today, true); check(text('#birthday-error').includes('before today'), 'Birthday rejects the present date');
    fill('birthday', '2000-05-20', true); check(text('#birthday-helper').includes('You are'), 'Birthday calculates and displays age');
    fill('password', 'weak', true); check(!!text('#password-error'), 'Weak password is rejected');
    fill('password', 'Considered123'); check(d.querySelectorAll('.requirements .met').length === 4, 'Password checklist reflects all requirements');
    fill('confirmPassword', 'mismatch'); submit(); check(text('#confirmPassword-error').includes('don’t match'), 'Password mismatch is rejected');
    fill('confirmPassword', 'Considered123'); submit(); await sleep(40);
    check(text('#view-heading').includes('everything look right'), 'Valid account details open review');
    check(!text('#view').includes('Considered123'), 'Review does not expose password');
    click('[data-edit="1"]'); await sleep(40);
    check(d.getElementById('firstName').value === 'Alex', 'Edit preserves prior values');
    check(d.getElementById('phone-country').value === 'PH' && d.getElementById('phone').value === '917 123 4567', 'Review edit preserves phone country and national number');
    fill('middleName', 'marie'); submit(); await sleep(40);
    check(text('#view').includes('Alex Marie Rivera'), 'Optional middle name appears in review');
    click('[data-edit="1"]'); await sleep(40);
    check(d.getElementById('middleName').value === 'Marie', 'Middle name is preserved when editing');
    fill('middleName', ''); fill('firstName', 'Alexandra'); submit(); await sleep(40);
    check(text('#view').includes('Alexandra Rivera'), 'Save and review reflects edited details');
    submit();
    check(text('#agreement-error').includes('Accept the Terms'), 'Account creation requires agreement to the terms and privacy policy');
    click('#agreement');
    check(d.getElementById('agreement').checked, 'Agreement can be accepted before account creation');
    for (const [scenario, message, delay] of [['network', 'check your internet connection', 1150], ['server', 'temporarily unavailable', 1150], ['timeout', 'took too long', 2550]]) {
      click('[data-action="demo"]'); d.getElementById('demo-scenario').value = scenario; click('#demo-done');
      submit(); await sleep(delay);
      check(text('#form-error').includes(message), `${scenario} error is contextual`);
      check(text('#view').includes('Alexandra Rivera'), `${scenario} error preserves review data`);
      check(!d.querySelector('[type="submit"]').disabled, `${scenario} allows retry`);
    }
    submit(); await sleep(1150);
    check(text('#view-heading') === 'Account created successfully', 'Retry reaches confirmation');
    check(!d.getElementById('success-toast').hidden && text('#toast-title') === 'Account created successfully', 'Account creation shows a success toast');
    check(text('#view').includes('alex@example.com'), 'Confirmation identifies created demo account');
    click('[data-action="dashboard"]'); check(text('#view-heading').includes('Alexandra'), 'Confirmation connects to demo destination');
    click('[data-action="signout"]'); click('[data-action="signup"]');
    check(d.getElementById('firstName').value === '', 'Starting over clears previous personal details');
    console.log(`ALL ${count} TESTS PASSED`); results.textContent += `\n\nALL ${count} TESTS PASSED`;
    document.body.dataset.testResult = 'passed';
  } catch (error) { console.error('TEST FAILED:', error.message); results.textContent += `\nFAILED: ${error.message}`; document.body.dataset.testResult = 'failed'; }
});
