/* Layout verification on the real page, never a width-approximating iframe. */
(async () => {
  await document.fonts.ready;
  await new Promise(resolve => setTimeout(resolve, 300));
  const form = document.getElementById('signup-form');
  const heightBefore = form.getBoundingClientRect().height;
  const positions = [...form.querySelectorAll('input')].map(input => [input, input.getBoundingClientRect().top + scrollY]);
  const scenarios = [
    { firstName: 'Enter your first name.', lastName: 'Enter your last name.', email: 'Enter your email address.', phone: 'Enter your phone number.' },
    { firstName: 'Use letters with single spaces, apostrophes, or hyphens between parts.', lastName: 'Numbers and symbols weren’t added. Use letters.', middleName: 'Use 60 characters or fewer.', email: 'This email is already registered. Sign in or use another email address.', phone: 'Check the country code and use 7–15 digits with standard grouping.' }
  ];
  let stable = true;
  for (const errors of scenarios) {
    for (const name of ['firstName', 'lastName', 'middleName', 'email', 'phone']) displayError(name, errors[name] || '');
    stable = stable && Math.abs(form.getBoundingClientRect().height - heightBefore) < 1;
    stable = stable && positions.every(([input, y]) => Math.abs(input.getBoundingClientRect().top + scrollY - y) < 1);
  }
  // Leave representative errors visible without inventing an optional-field requirement.
  displayError('middleName', '');
  console.log(stable ? 'PASS: inline errors preserve form height and input positions at this viewport.' : 'FAIL: inline errors changed layout.');
  document.body.dataset.validationLayout = stable ? 'passed' : 'failed';
})();
